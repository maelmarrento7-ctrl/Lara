package com.equipeargentina.panel

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat

/**
 * Serviço que desenha o painel flutuante sobre QUALQUER aplicativo.
 * - Bolha (ícone) sempre visível, arrastável.
 * - Toque na bolha expande/recolhe o painel completo (Principal / Ajustes / Gelo / IA / Otimizar).
 * - Foreground service para o sistema não matar o painel.
 */
class FloatingPanelService : Service() {

    private lateinit var windowManager: WindowManager
    private var bubbleView: View? = null
    private var panelView: View? = null
    private var panelExpanded = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTIF_ID, buildNotification())
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    private fun buildNotification(): Notification {
        val channelId = "equipe_argentina_panel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            val ch = NotificationChannel(
                channelId,
                "Painel EQUIPE ARGENTINA",
                NotificationManager.IMPORTANCE_LOW
            )
            nm.createNotificationChannel(ch)
        }
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("EQUIPE ARGENTINA")
            .setContentText("Painel flutuante ativo")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setOngoing(true)
            .build()
    }

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun showBubble() {
        val inflater = LayoutInflater.from(this)
        bubbleView = inflater.inflate(R.layout.floating_bubble, null)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 0
        params.y = 300

        // Drag + click
        bubbleView!!.setOnTouchListener(object : View.OnTouchListener {
            private var initX = 0
            private var initY = 0
            private var touchX = 0f
            private var touchY = 0f
            private var moved = false

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initX = params.x; initY = params.y
                        touchX = event.rawX; touchY = event.rawY
                        moved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - touchX).toInt()
                        val dy = (event.rawY - touchY).toInt()
                        if (Math.abs(dx) > 15 || Math.abs(dy) > 15) moved = true
                        params.x = initX + dx
                        params.y = initY + dy
                        windowManager.updateViewLayout(bubbleView, params)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) togglePanel()
                        return true
                    }
                }
                return false
            }
        })

        windowManager.addView(bubbleView, params)
    }

    private fun togglePanel() {
        if (panelExpanded) hidePanel() else showPanel()
    }

    private fun showPanel() {
        val inflater = LayoutInflater.from(this)
        panelView = inflater.inflate(R.layout.floating_panel, null)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 60
        params.y = 250

        val title = panelView!!.findViewById<TextView>(R.id.txtPanelTitle)
        title.text = "EQUIPE ARGENTINA 1.0"

        // Botão fechar / minimizar painel
        panelView!!.findViewById<View>(R.id.btnMinimize).setOnClickListener { hidePanel() }

        // Tabs laterais
        val content = panelView!!.findViewById<LinearLayout>(R.id.panelContent)
        setupTab(R.id.tabPrincipal, content) { showPrincipal(content) }
        setupTab(R.id.tabAjustes, content)   { showAjustes(content) }
        setupTab(R.id.tabGelo, content)      { showGelo(content) }
        setupTab(R.id.tabIA, content)        { showIA(content) }
        setupTab(R.id.tabOtimizar, content)  { showOtimizar(content) }

        // Conteúdo inicial
        showPrincipal(content)

        windowManager.addView(panelView, params)
        panelExpanded = true

        // Permite arrastar o painel pela barra superior
        val header = panelView!!.findViewById<View>(R.id.panelHeader)
        header.setOnTouchListener(object : View.OnTouchListener {
            private var initX = 0
            private var initY = 0
            private var touchX = 0f
            private var touchY = 0f
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initX = params.x; initY = params.y
                        touchX = event.rawX; touchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = initX + (event.rawX - touchX).toInt()
                        params.y = initY + (event.rawY - touchY).toInt()
                        windowManager.updateViewLayout(panelView, params)
                        return true
                    }
                }
                return false
            }
        })
    }

    private fun setupTab(id: Int, content: LinearLayout, action: () -> Unit) {
        panelView!!.findViewById<View>(id).setOnClickListener { action() }
    }

    private fun hidePanel() {
        panelView?.let { runCatching { windowManager.removeView(it) } }
        panelView = null
        panelExpanded = false
    }

    // ============ Conteúdos das 5 abas ============

    private fun showPrincipal(content: LinearLayout) {
        content.removeAllViews()
        val v = LayoutInflater.from(this).inflate(R.layout.tab_principal, content, false)
        content.addView(v)
    }

    private fun showAjustes(content: LinearLayout) {
        content.removeAllViews()
        val v = LayoutInflater.from(this).inflate(R.layout.tab_ajustes, content, false)
        content.addView(v)
    }

    private fun showGelo(content: LinearLayout) {
        content.removeAllViews()
        val v = LayoutInflater.from(this).inflate(R.layout.tab_gelo, content, false)
        content.addView(v)
    }

    private fun showIA(content: LinearLayout) {
        content.removeAllViews()
        val v = LayoutInflater.from(this).inflate(R.layout.tab_ia, content, false)
        content.addView(v)
        Toast.makeText(this, "IA carregada", Toast.LENGTH_SHORT).show()
    }

    private fun showOtimizar(content: LinearLayout) {
        content.removeAllViews()
        val v = LayoutInflater.from(this).inflate(R.layout.tab_otimizar, content, false)
        content.addView(v)
    }

    override fun onDestroy() {
        super.onDestroy()
        bubbleView?.let { runCatching { windowManager.removeView(it) } }
        panelView?.let { runCatching { windowManager.removeView(it) } }
    }

    companion object { private const val NOTIF_ID = 7777 }
}
