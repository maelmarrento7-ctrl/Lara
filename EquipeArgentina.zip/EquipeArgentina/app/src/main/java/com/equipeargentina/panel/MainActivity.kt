package com.equipeargentina.panel

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.equipeargentina.panel.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Botão ON/OFF central → ativa o painel flutuante
        binding.btnPower.setOnClickListener {
            if (canDrawOverlays()) {
                startFloatingPanel()
            } else {
                requestOverlayPermission()
            }
        }

        // Botão "mostrar ícone flutuante" (olho aberto)
        binding.btnShowFloating.setOnClickListener {
            if (canDrawOverlays()) {
                startFloatingPanel()
                Toast.makeText(this, "Painel flutuante ATIVADO", Toast.LENGTH_SHORT).show()
            } else {
                requestOverlayPermission()
            }
        }

        // Botão olho fechado → desliga o painel
        binding.btnHideFloating.setOnClickListener {
            stopService(Intent(this, FloatingPanelService::class.java))
            Toast.makeText(this, "Painel flutuante DESATIVADO", Toast.LENGTH_SHORT).show()
        }
    }

    private fun canDrawOverlays(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else true
    }

    private fun requestOverlayPermission() {
        Toast.makeText(
            this,
            "Conceda permissão de sobreposição para EQUIPE ARGENTINA",
            Toast.LENGTH_LONG
        ).show()
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        )
        startActivityForResult(intent, REQ_OVERLAY)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_OVERLAY && canDrawOverlays()) {
            startFloatingPanel()
        }
    }

    private fun startFloatingPanel() {
        val svc = Intent(this, FloatingPanelService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(svc)
        } else {
            startService(svc)
        }
        // Move app para background para mostrar que sobrepõe outros apps
        val home = Intent(Intent.ACTION_MAIN)
        home.addCategory(Intent.CATEGORY_HOME)
        home.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(home)
    }

    companion object {
        private const val REQ_OVERLAY = 1001
    }
}
