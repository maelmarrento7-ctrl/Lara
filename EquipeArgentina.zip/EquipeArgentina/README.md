# EQUIPE ARGENTINA — Painel Flutuante Android

App Android nativo (Kotlin) que exibe um **painel flutuante funcional sobre qualquer outro aplicativo**, baseado no design do FREESTYLE PANEL, com a marca trocada para **EQUIPE ARGENTINA**.

## ✨ Funcionalidades

- ✅ Tela principal com botão **ON/OFF** central, timer, ícone flutuante e card "Ícone do Aplicativo"
- ✅ **Bolha flutuante arrastável** que aparece sobre QUALQUER app (jogos, navegadores etc.)
- ✅ Toque na bolha → expande o painel completo com 5 abas:
  - **Principal** (Ponto HH: Cabeça / Pescoço / Corpo Inteiro)
  - **Ajustes** (Travamento de Alvo, Controle de Rec., Botão de Truque, Mira Pro)
  - **Gelo** (Normal / Invertido)
  - **IA** (IA Aimbot, Tracking, Sensibilidade)
  - **Otimizar** (Melhorar FPS, Reduzir travamentos, Otimizar RAM, Limpar Memória)
- ✅ **Foreground Service** com notificação persistente (não é morto pelo sistema)
- ✅ Painel arrastável pela barra superior
- ✅ Permissão `SYSTEM_ALERT_WINDOW` solicitada automaticamente na 1ª execução
- ✅ Cores e tipografia idênticas ao mockup (preto + verde neon `#00E676`)

## 📦 Como compilar a APK

### Pré-requisitos
- **Android Studio Hedgehog (2023.1)** ou superior
- **JDK 17**
- **Android SDK 34** (compileSdk) e SDK 23+ (minSdk)
- Gradle 8.5 (já configurado no wrapper)

### Passos

1. Abra o **Android Studio** → `File` → `Open` → selecione a pasta `EquipeArgentina/`.
2. Aguarde o Gradle Sync terminar (baixa dependências automaticamente).
3. Conecte um celular Android via USB com **depuração USB** ativada **OU** crie um emulador (API 23+).
4. Clique em **Run ▶** (Shift+F10) — o app será instalado e executado.
5. Para gerar a **APK assinada**:
   - Menu `Build` → `Generate Signed Bundle / APK…` → **APK**
   - Crie uma keystore nova (siga o assistente)
   - Escolha a build variant `release` → Finish
   - APK ficará em `app/release/app-release.apk`

### Compilando via terminal (sem Android Studio)
```bash
cd EquipeArgentina
./gradlew assembleDebug
# APK gerada em: app/build/outputs/apk/debug/app-debug.apk
```

## 📱 Como usar no celular

1. Instale a APK no Android.
2. Abra o app **EQUIPE ARGENTINA**.
3. Toque no botão **ON** central (ou no botão olho aberto verde).
4. O Android pedirá a permissão **"Exibir sobre outros apps"** → conceda.
5. O app vai automaticamente para o background e a **bolha flutuante verde** aparecerá na tela.
6. **Arraste** a bolha para qualquer canto da tela.
7. **Toque** na bolha para abrir/fechar o painel completo.
8. Abra qualquer outro aplicativo (jogo, navegador, WhatsApp etc.) — a bolha continuará visível por cima.

## ⚠️ Observações importantes

- A permissão **"Sobreposição de tela"** só é concedida manualmente pelo usuário — é uma exigência de segurança do Android.
- Em **Android 14+** o `foregroundServiceType="specialUse"` é obrigatório (já configurado).
- Em **MIUI / ColorOS / OneUI** pode ser preciso ativar manualmente em "Outras permissões → Exibir sobre outros apps" e desativar otimização de bateria para o app.
- Os toggles do painel (FPS, IA, etc.) são **estados de UI funcionais** — para ações reais sobre o sistema você precisaria implementar a lógica de cada feature.

## 🗂️ Estrutura do projeto

```
EquipeArgentina/
├── app/
│   ├── build.gradle
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/equipeargentina/panel/
│       │   ├── MainActivity.kt          ← Tela principal
│       │   └── FloatingPanelService.kt  ← Painel flutuante (Service)
│       └── res/
│           ├── layout/
│           │   ├── activity_main.xml    ← Tela principal
│           │   ├── floating_bubble.xml  ← Bolha verde
│           │   ├── floating_panel.xml   ← Painel completo (header + tabs)
│           │   └── tab_*.xml            ← Conteúdo das 5 abas
│           ├── drawable/                ← Ícones vetoriais + backgrounds
│           ├── values/                  ← strings, colors, themes, styles
│           └── mipmap-*/                ← Ícone do app
├── build.gradle
├── settings.gradle
└── gradle/wrapper/                      ← Gradle 8.5
```

## 🎨 Personalização rápida

- **Mudar nome do painel:** `app/src/main/res/values/strings.xml` → `panel_title_full`
- **Mudar cor verde:** `app/src/main/res/values/colors.xml` → `green_neon`
- **Adicionar nova aba:** crie `tab_xxx.xml` em `res/layout/` e adicione handler em `FloatingPanelService.kt`

---
Projeto desenvolvido para fins de **estudo de desenvolvimento Android**.
